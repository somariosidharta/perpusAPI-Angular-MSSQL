import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './users/users.component';
import { ShowUserComponent } from './users/show-user/show-user.component';
import { AddEditUserComponent } from './users/add-edit-user/add-edit-user.component';
import { BooksComponent } from './books/books.component';
import { ShowBookComponent } from './books/show-book/show-book.component';
import { AddEditBookComponent } from './books/add-edit-book/add-edit-book.component';
import { BorrowedComponent } from './borrowed/borrowed.component';
import { ShowBorrowComponent } from './borrowed/show-borrow/show-borrow.component';
import { AddEditBorrowComponent } from './borrowed/add-edit-borrow/add-edit-borrow.component';
import { SharedService} from './shared.service';

import {HttpClientModule} from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    ShowUserComponent,
    AddEditUserComponent,
    BooksComponent,
    ShowBookComponent,
    AddEditBookComponent,
    BorrowedComponent,
    ShowBorrowComponent,
    AddEditBorrowComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
