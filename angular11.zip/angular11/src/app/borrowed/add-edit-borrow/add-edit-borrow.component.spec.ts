import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditBorrowComponent } from './add-edit-borrow.component';

describe('AddEditBorrowComponent', () => {
  let component: AddEditBorrowComponent;
  let fixture: ComponentFixture<AddEditBorrowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditBorrowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditBorrowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
