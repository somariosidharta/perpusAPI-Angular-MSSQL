import { Component, OnInit, Input } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-borrow',
  templateUrl: './add-edit-borrow.component.html',
  styleUrls: ['./add-edit-borrow.component.css']
})
export class AddEditBorrowComponent implements OnInit {

  constructor(private service:SharedService) { }

  @Input() borrow:any;
  BookId:any;
  BookName:any;
  UserId:any;
  UserName:any;
  IsActive:any;
  BorrowedId:any;
  User:any;
  Book:any;

  BooksList:any=[];
  UsersList:any=[];
  selected: number = 1;


  ngOnInit(): void {
    this.loadAllList();
  }

  loadAllList(){
    this.service.getAllUserNames().subscribe((data:any)=>{
      this.UsersList =data
    });
    this.service.getAllBooksNames().subscribe((data:any)=>{
      this.BooksList =data
    });
      this.BookId = this.borrow.BookId
      this.BookName = this.borrow.BookName
      this.UserId = this.borrow.UserId
      this.UserName = this.borrow.UserName
      this.IsActive = this.borrow.IsActive
      this.BorrowedId = this.borrow.BorrowedId
  }

 

  addBorrow(){
    var val = {bookID:this.BookId,
      UserId:this.UserId,
      IsActive:this.IsActive,
      BorrowedId:this.BorrowedId};
    this.service.addBorrow(val).subscribe(res=>{
      alert(res.toString());
    });
  }

  updateBorrow(){
    var val = {bookID:this.borrow.BookId,
      UserId:this.borrow.UserId,
      IsActive:this.IsActive,
      BorrowedId:this.BorrowedId};
      
      console.log(val)
    this.service.updateBorrow(val).subscribe(res=>{
      alert(res.toString());
    });
  } 

  selectUserName(id:any) {
    //getted from event
    this.UserId=id
    console.log(this.UserId)
    console.log(id);
    //getted from binding
    console.log(this.selected)
  }

  selectBookName(id: any) {
    //getted from event
    this.BookId=id
    console.log(this.BookId)
    console.log(id);
    //getted from binding
    console.log(this.selected)
  }

  

}
