import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-show-borrow',
  templateUrl: './show-borrow.component.html',
  styleUrls: ['./show-borrow.component.css']
})
export class ShowBorrowComponent implements OnInit {

  constructor(private service:SharedService) { }

  borrowedsList:any[];

  ModalTitle:string;
  ActivateAddEditBorrowComp:boolean=false;
  borrow:any;

  BorrowIdFilter:string="";
  BookIdFilter:string="";
  BookNameFilter:string="";
  UserNameFilter:string="";
  IsActiveFilter:string="";
  BorrowListWithoutFilter:any=[];

  ngOnInit(): void {
    this.refreshBorrowsList();
  }

  addClick(){
    this.borrow={
      BorrowId:0,
      BookId:"",
      BookName:"",
      UserName:"",
      IsActive:true
    }
    this.ModalTitle="Add Borrow";
    this.ActivateAddEditBorrowComp=true;

  }

  closeClick(){
    this.ActivateAddEditBorrowComp=false;
    this.refreshBorrowsList();

  }

  editClick(item){
    this.borrow=item;
    this.ModalTitle="Edit Borrow";
    this.ActivateAddEditBorrowComp=true;

  }

  refreshBorrowsList(){
    this.service.getBorrowList().subscribe(data=>{
      this.borrowedsList=data;
      this.BorrowListWithoutFilter=data;
    })
  }

  FilterFn(){
    var BorrowIdFilter = this.BorrowIdFilter;
    var BookNameFilter = this.BookNameFilter;
    var UserNameFilter = this.UserNameFilter;
    var BookIdFilter = this.BookIdFilter;
    var IsActiveFilter = this.IsActiveFilter;

    this.borrowedsList = this.BorrowListWithoutFilter.filter(function (el){
      return el.BorrowedId.toString().toLowerCase().includes(
        BorrowIdFilter.toString().trim().toLowerCase()
      )&&
      el.BookName.toString().toLowerCase().includes(
        BookNameFilter.toString().trim().toLowerCase()
      )&&
      el.BookId.toString().toLowerCase().includes(
        BookIdFilter.toString().trim().toLowerCase()
      )&&
      el.UserName.toString().toLowerCase().includes(
        UserNameFilter.toString().trim().toLowerCase()
      )
      &&
      el.IsActive.toString().toLowerCase().includes(
        IsActiveFilter.toString().trim().toLowerCase()
      )
    });
  }

}
