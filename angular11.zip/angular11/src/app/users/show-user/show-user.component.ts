import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-show-user',
  templateUrl: './show-user.component.html',
  styleUrls: ['./show-user.component.css']
})
export class ShowUserComponent implements OnInit {

  constructor(private service:SharedService) { }

  usersList:any[];

  ModalTitle:string;
  ActivateAddEditUserComp:boolean=false;
  user:any;

  UserIdFilter:string="";
  UserNameFilter:string="";
  UserListWithoutFilter:any=[];

  ngOnInit(): void {
    this.refreshUsersList();
  }

  addClick(){
    this.user={
      UserId:0,
      UserName:"",
      FullName:"",
      IsActive:true
    }
    this.ModalTitle="Add User";
    this.ActivateAddEditUserComp=true;

  }

  closeClick(){
    this.ActivateAddEditUserComp=false;
    this.refreshUsersList();

  }

  editClick(item){
    this.user=item;
    this.ModalTitle="Edit User";
    this.ActivateAddEditUserComp=true;

  }

  refreshUsersList(){
    this.service.getUserList().subscribe(data=>{
      this.usersList=data;
      this.UserListWithoutFilter=data;
    })
  }

  FilterFn(){
    var UserIdFilter = this.UserIdFilter;
    var UserNameFilter = this.UserNameFilter;

    this.usersList = this.UserListWithoutFilter.filter(function (el){
      return el.UserId.toString().toLowerCase().includes(
        UserIdFilter.toString().trim().toLowerCase()
      )&&
      el.UserName.toString().toLowerCase().includes(
        UserNameFilter.toString().trim().toLowerCase()
      )
    });
  }

}
