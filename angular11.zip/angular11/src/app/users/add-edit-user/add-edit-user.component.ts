import { Component, OnInit, Input } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.css']
})
export class AddEditUserComponent implements OnInit {

  constructor(private service:SharedService) { }

  @Input() user:any;
  UserID:any;
  UserName:any;
  FullName:any;
  IsActive:any;


  ngOnInit(): void {
    this.UserID = this.user.UserId
    this.UserName = this.user.UserName
    this.FullName = this.user.FullName
    this.IsActive = this.user.IsActive
  }

 

  addUser(){
    var val = {userID:this.UserID,
      UserName:this.UserName,
      FullName:this.FullName,
      IsActive:this.IsActive};
    this.service.addUser(val).subscribe(res=>{
      alert(res.toString());
    });
  }

  updateUser(){
    var val = {userID:this.UserID,
      UserName:this.UserName,
      FullName:this.FullName,
      IsActive:this.IsActive};
    this.service.updateUser(val).subscribe(res=>{
      alert(res.toString());
    });
  } 

}