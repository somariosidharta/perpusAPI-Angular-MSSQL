import { Component, OnInit, Input } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-add-edit-book',
  templateUrl: './add-edit-book.component.html',
  styleUrls: ['./add-edit-book.component.css']
})
export class AddEditBookComponent implements OnInit {

  constructor(private service:SharedService) { }

  @Input() book:any;
  BookID:any;
  BookName:any;
  Qty:any;


  ngOnInit(): void {
    this.BookID = this.book.BookId
    this.BookName = this.book.BookName
    this.Qty = this.book.Qty
  }

 

  addBook(){
    var val = {bookID:this.BookID,
      BookName:this.BookName,
      Qty:this.Qty};
    this.service.addBook(val).subscribe(res=>{
      alert(res.toString());
    });
  }

  updateBook(){
    var val = {bookID:this.BookID,
      BookName:this.BookName,
      Qty:this.Qty};
    this.service.updateBook(val).subscribe(res=>{
      alert(res.toString());
    });
  } 

}
