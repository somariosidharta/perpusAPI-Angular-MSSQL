import { Component, OnInit } from '@angular/core';
import {SharedService} from 'src/app/shared.service';

@Component({
  selector: 'app-show-book',
  templateUrl: './show-book.component.html',
  styleUrls: ['./show-book.component.css']
})
export class ShowBookComponent implements OnInit {

  constructor(private service:SharedService) { }

  booksList:any[];

  ModalTitle:string;
  ActivateAddEditBookComp:boolean=false;
  book:any;

  BookIdFilter:string="";
  BookNameFilter:string="";
  BookListWithoutFilter:any=[];

  ngOnInit(): void {
    this.refreshBooksList();
  }

  addClick(){
    this.book={
      BookId:0,
      BookName:"",
      Qty:""
    }
    this.ModalTitle="Add Book";
    this.ActivateAddEditBookComp=true;

  }

  closeClick(){
    this.ActivateAddEditBookComp=false;
    this.refreshBooksList();

  }

  editClick(item){
    this.book=item;
    this.ModalTitle="Edit Book";
    this.ActivateAddEditBookComp=true;

  }

  refreshBooksList(){
    this.service.getBookList().subscribe(data=>{
      this.booksList=data;
      this.BookListWithoutFilter=data;
    })
  }

  FilterFn(){
    var BookIdFilter = this.BookIdFilter;
    var BookNameFilter = this.BookNameFilter;

    this.booksList = this.BookListWithoutFilter.filter(function (el){
      return el.BookId.toString().toLowerCase().includes(
        BookIdFilter.toString().trim().toLowerCase()
      )&&
      el.BookName.toString().toLowerCase().includes(
        BookNameFilter.toString().trim().toLowerCase()
      )
    });
  }

}
