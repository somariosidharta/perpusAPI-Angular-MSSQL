import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
readonly APIurl="http://localhost:5000/api";
readonly PhotoUrl="http://localhost:5000/Photos";
  constructor(private http:HttpClient) { }

  getUserList():Observable<any[]>{
    return this.http.get<any>(this.APIurl+'/user')
  }

  addUser(val:any){
    return this.http.post(this.APIurl+'/user',val)
  }

  updateUser(val:any){
    return this.http.put(this.APIurl+'/user',val)
  }

  deleteUser(val:any){
    return this.http.delete(this.APIurl+'/user'+val)
  }

  getBookList():Observable<any[]>{
    return this.http.get<any>(this.APIurl+'/books')
  }

  addBook(val:any){
    return this.http.post(this.APIurl+'/books',val)
  }

  updateBook(val:any){
    return this.http.put(this.APIurl+'/books',val)
  }

  deleteBook(val:any){
    return this.http.delete(this.APIurl+'/books'+val)
  }

  getBorrowList():Observable<any[]>{
    return this.http.get<any>(this.APIurl+'/borrowed')
  }

  addBorrow(val:any){
    return this.http.post(this.APIurl+'/borrowed',val)
  }

  updateBorrow(val:any){
    return this.http.put(this.APIurl+'/borrowed',val)
  }

  deleteBorrow(val:any){
    return this.http.delete(this.APIurl+'/borrowed'+val)
  }

  UploadPhoto(val:any){
    return this.http.post(this.APIurl+'/books/savefile',val)
  }

  getAllBooksNames():Observable<any[]>{
    return this.http.options<any[]>(this.APIurl+'/books');
  }
  getAllUserNames():Observable<any[]>{
    return this.http.options<any[]>(this.APIurl+'/user');
  }
}
